export async function GET() {
  const manifest = {
    name: "FARSCORE",
    description:
      "View your Farcaster account statistics including likes, casts, recasts, and Neynar score. Search any Farcaster account to see their activity.",
    shortDescription: "Track Farcaster Activity",
    homepage: "https://v0-far.vercel.app",
    image: "https://v0-far.vercel.app/farscore-logo.png",
    backgroundColor: "#6200EA",
    website: "https://v0-far.vercel.app",
    splashImageUrl: "https://v0-far.vercel.app/farscore-logo.png",
    splashBackgroundColor: "#6200EA",
  }

  return new Response(JSON.stringify(manifest), {
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
    },
  })
}
