import { type NextRequest, NextResponse } from "next/server"

const NEYNAR_API_KEY = "E7B9F344-4327-4C0C-BA28-A363B88CAB7B"

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const fid = searchParams.get("fid")
  const username = searchParams.get("username")

  try {
    let response

    if (username) {
      const cleanUsername = username.startsWith("@") ? username.slice(1) : username

      // Lookup user by username first to get their FID
      response = await fetch(
        `https://api.neynar.com/v2/farcaster/user/by_username?username=${encodeURIComponent(cleanUsername)}`,
        {
          headers: {
            api_key: NEYNAR_API_KEY,
            accept: "application/json",
          },
        },
      )

      if (!response.ok) {
        const errorText = await response.text()
        console.error(`Neynar API error: ${response.status}`, errorText)
        if (response.status === 429) {
          throw new Error("Rate limit exceeded. Please wait a minute before trying again.")
        }
        throw new Error(`User not found: ${cleanUsername}`)
      }

      const userData = await response.json()
      return NextResponse.json({
        user: userData.user,
      })
    } else {
      // Use FID lookup (default)
      const fidToUse = fid || "3"
      response = await fetch(`https://api.neynar.com/v2/farcaster/user/bulk?fids=${fidToUse}`, {
        headers: {
          api_key: NEYNAR_API_KEY,
          accept: "application/json",
          "x-neynar-experimental": "true",
        },
      })

      if (!response.ok) {
        const errorText = await response.text()
        console.error(`Neynar API error: ${response.status}`, errorText)
        if (response.status === 429) {
          throw new Error("Rate limit exceeded. Please wait a minute before trying again.")
        }
        throw new Error(`Neynar API error: ${response.status}`)
      }

      const data = await response.json()
      return NextResponse.json({
        user: data.users[0],
      })
    }
  } catch (error) {
    console.error("Error fetching user data:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to fetch user data" },
      { status: error instanceof Error && error.message.includes("Rate limit") ? 429 : 500 },
    )
  }
}
