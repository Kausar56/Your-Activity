"use client"

import type React from "react"
import { Analytics } from "@vercel/analytics/next"
import "./globals.css"

export default function RootLayoutClient({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className="font-sans antialiased bg-[#0d1f2d]">
        {children}
        <Analytics />
      </body>
    </html>
  )
}
