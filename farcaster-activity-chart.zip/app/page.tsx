import FarcasterAccountActivity from "@/components/farcaster-account-activity"

export default function Home() {
  return <FarcasterAccountActivity />
}
