"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import {
  Loader2,
  Heart,
  MessageSquare,
  Repeat2,
  Search,
  ChevronDown,
  Home,
  User,
  Share2,
  Download,
  RefreshCw,
  TrendingUp,
} from "lucide-react"
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface ActivityData {
  date: string
  likes: number
  casts: number
  recasts: number
}

interface UserProfile {
  fid: number
  username: string
  display_name: string
  pfp_url: string
  profile: {
    bio: {
      text: string
    }
  }
  follower_count: number
  following_count: number
  verifications: string[]
  active_status: string
}

interface ActivityStats {
  total_likes: number
  total_casts: number
  total_recasts: number
  neynar_score: number
}

function CustomDot(props: any) {
  const { cx, cy, index, payload, dataKey } = props
  if (cx == null || cy == null) return null

  const colors: Record<string, string> = {
    likes: "#FF6B98",
    casts: "#4C59FF",
    recasts: "#4CCB8F",
  }
  const color = colors[dataKey] || "#FF6B98"

  return (
    <g>
      <circle cx={cx} cy={cy} r={6} fill="none" stroke="#ffffff" strokeWidth={2} opacity={0.95} />
      <circle cx={cx} cy={cy} r={3.5} fill={color} stroke="transparent" />
    </g>
  )
}

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload || !payload.length) return null
  return (
    <div className="rounded-lg border bg-background p-3 shadow-lg">
      <div className="font-semibold text-sm mb-2 text-white">{label}</div>
      {payload.map((entry: any, index: number) => (
        <div key={index} className="flex items-center gap-2 text-sm text-white">
          <div className="h-2 w-2 rounded-full" style={{ backgroundColor: entry.color }} />
          <span className="capitalize">{entry.name}:</span>
          <span className="font-semibold">{entry.value}</span>
        </div>
      ))}
    </div>
  )
}

export default function FarcasterAccountActivity() {
  const [activityData, setActivityData] = useState<ActivityData[]>([])
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const [stats, setStats] = useState<ActivityStats>({
    total_likes: 0,
    total_casts: 0,
    total_recasts: 0,
    neynar_score: 0,
  })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [fid, setFid] = useState<number>(239530)
  const [timePeriod, setTimePeriod] = useState<"24h" | "week" | "month">("week")
  const [searchInput, setSearchInput] = useState<string>("")
  const [isSearching, setIsSearching] = useState(false)
  const [cachedProfiles, setCachedProfiles] = useState<Map<number, { profile: UserProfile; timestamp: number }>>(
    new Map(),
  )
  const [refreshing, setRefreshing] = useState(false)
  const [userNotFound, setUserNotFound] = useState(false)
  const [cachedActivity, setCachedActivity] = useState<
    Map<string, { data: ActivityData[]; stats: ActivityStats; timestamp: number }>
  >(new Map())
  const [showProfileGenerator, setShowProfileGenerator] = useState(false)
  const [cardBackground, setCardBackground] = useState("gradient-pink")

  const fetchData = async () => {
    setRefreshing(true)
    setLoading(true)
    setError(null)
    setUserNotFound(false)

    try {
      const cached = cachedProfiles.get(fid)
      const now = Date.now()
      const cacheAge = cached ? now - cached.timestamp : Number.POSITIVE_INFINITY

      let profileData

      if (cached && cacheAge < 5 * 60 * 1000) {
        profileData = cached.profile
        setUserProfile(profileData)
      } else {
        const profileResponse = await fetch(`/api/farcaster/user?fid=${fid}`)
        if (!profileResponse.ok) {
          const errorData = await profileResponse.json()
          if (errorData.error?.includes("Rate limit exceeded")) {
            throw new Error(
              "Rate limit reached. Please wait a minute before searching again. Using cached data if available.",
            )
          }
          throw new Error(errorData.error || "Failed to fetch user profile")
        }
        profileData = (await profileResponse.json()).user
        setUserProfile(profileData)
        setCachedProfiles(new Map(cachedProfiles).set(fid, { profile: profileData, timestamp: now }))
      }

      const activityCacheKey = `${fid}-${timePeriod}`
      const cachedActivityData = cachedActivity.get(activityCacheKey)
      const activityCacheAge = cachedActivityData ? now - cachedActivityData.timestamp : Number.POSITIVE_INFINITY

      if (cachedActivityData && activityCacheAge < 5 * 60 * 1000) {
        setActivityData(cachedActivityData.data)
        setStats(cachedActivityData.stats)
      } else {
        const activityResponse = await fetch(`/api/farcaster/activity?fid=${fid}&period=${timePeriod}`)
        if (!activityResponse.ok) {
          const errorData = await activityResponse.json()
          if (errorData.error?.includes("Rate limit exceeded")) {
            if (cachedActivityData) {
              setActivityData(cachedActivityData.data)
              setStats(cachedActivityData.stats)
              throw new Error("Rate limit reached. Showing cached activity data.")
            }
            throw new Error("Rate limit reached. Please wait a minute before trying again.")
          }
          throw new Error("Failed to fetch activity data")
        }
        const activityResult = await activityResponse.json()

        setActivityData(activityResult.chartData)
        setStats(activityResult.stats)
        setCachedActivity(
          new Map(cachedActivity).set(activityCacheKey, {
            data: activityResult.chartData,
            stats: activityResult.stats,
            timestamp: now,
          }),
        )
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
      console.error("Error fetching Farcaster data:", err)
      const cached = cachedProfiles.get(fid)
      if (cached && !userProfile) {
        setUserProfile(cached.profile)
      }
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  const handleSearch = async () => {
    if (!searchInput.trim()) return

    setIsSearching(true)
    setError(null)
    setUserNotFound(false)

    try {
      const isNumeric = /^\d+$/.test(searchInput.trim())

      if (isNumeric) {
        setFid(Number.parseInt(searchInput.trim()))
      } else {
        const usernameCache = Array.from(cachedProfiles.values()).find(
          (cached) =>
            cached.profile.username.toLowerCase() === searchInput.trim().toLowerCase() ||
            `@${cached.profile.username.toLowerCase()}` === searchInput.trim().toLowerCase(),
        )

        if (usernameCache) {
          setFid(usernameCache.profile.fid)
        } else {
          const usernameResponse = await fetch(`/api/farcaster/user?username=${encodeURIComponent(searchInput.trim())}`)
          if (!usernameResponse.ok) {
            const errorData = await usernameResponse.json()
            if (errorData.error?.includes("Rate limit exceeded")) {
              throw new Error("Rate limit reached. Please wait a minute before searching again.")
            }
            setUserNotFound(true)
            setIsSearching(false)
            return
          }
          const userData = await usernameResponse.json()
          setFid(userData.user.fid)
          setCachedProfiles(
            new Map(cachedProfiles).set(userData.user.fid, { profile: userData.user, timestamp: Date.now() }),
          )
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to find user")
    } finally {
      setIsSearching(false)
    }
  }

  const handleRefresh = () => {
    fetchData()
  }

  const generateProfileCard = async () => {
    if (!userProfile) return

    const appUrl = window.location.origin
    const shareText = `🎨 Check out my Farcaster profile card!\n\n👤 ${userProfile.display_name} (@${userProfile.username})\n📊 Neynar Score: ${stats.neynar_score.toFixed(2)}\n👥 ${userProfile.follower_count} followers\n\n📊 Powered by FARSCORE\nView your stats: ${appUrl}?fid=${fid}`

    const warpcastUrl = `https://warpcast.com/~/compose?text=${encodeURIComponent(shareText)}`
    window.open(warpcastUrl, "_blank")
  }

  const cardBackgrounds = {
    "gradient-pink": "bg-gradient-to-br from-pink-300 via-purple-400 to-blue-400",
    "gradient-blue": "bg-gradient-to-br from-blue-400 via-cyan-400 to-teal-400",
    "gradient-orange": "bg-gradient-to-br from-orange-400 via-red-400 to-pink-400",
    "gradient-green": "bg-gradient-to-br from-green-400 via-emerald-400 to-cyan-400",
  }

  useEffect(() => {
    fetchData()
  }, [fid, timePeriod])

  const exportToCSV = () => {
    const csvContent = [
      ["Date", "Likes", "Casts", "Recasts"],
      ...activityData.map((d) => [d.date, d.likes, d.casts, d.recasts]),
    ]
      .map((row) => row.join(","))
      .join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `farcaster-activity-${userProfile?.username || fid}.csv`
    a.click()
    window.URL.revokeObjectURL(url)
  }

  const shareToFarcaster = () => {
    if (!userProfile || !stats) return

    const appUrl = window.location.origin
    const avgLikes = (stats.total_likes / (timePeriod === "24h" ? 1 : timePeriod === "week" ? 7 : 30)).toFixed(1)
    const avgCasts = (stats.total_casts / (timePeriod === "24h" ? 1 : timePeriod === "week" ? 7 : 30)).toFixed(1)
    const avgRecasts = (stats.total_recasts / (timePeriod === "24h" ? 1 : timePeriod === "week" ? 7 : 30)).toFixed(1)

    const periodText = timePeriod === "24h" ? "24 hours" : timePeriod === "week" ? "week" : "month"

    const text = `My Farcaster Activity (Last ${periodText}):\n\n📊 ${avgLikes} Likes/day\n✍️ ${avgCasts} Casts/day\n🔄 ${avgRecasts} Recasts/day\n🏆 Neynar Score: ${stats.neynar_score.toFixed(2)}\n\nCheck your stats at: ${appUrl}`

    const composerUrl = `https://warpcast.com/~/compose?text=${encodeURIComponent(text)}`
    window.open(composerUrl, "_blank")
  }

  const getTimePeriodLabel = () => {
    switch (timePeriod) {
      case "24h":
        return "Last 24 Hours Activity"
      case "week":
        return "Weekly Activity"
      case "month":
        return "Last 1 Month Activity"
      default:
        return "Select Activity Period"
    }
  }

  const getNeynarScoreColor = (score: number) => {
    if (score >= 0.7 && score <= 10) {
      return {
        bg: "bg-green-100/50",
        border: "border-green-300/60",
        textLabel: "text-green-700",
        textScore: "text-green-900",
      }
    } else if (score >= 0.5 && score < 0.7) {
      return {
        bg: "bg-orange-100/50",
        border: "border-orange-300/60",
        textLabel: "text-orange-700",
        textScore: "text-orange-900",
      }
    } else {
      return {
        bg: "bg-red-100/50",
        border: "border-red-300/60",
        textLabel: "text-red-700",
        textScore: "text-red-900",
      }
    }
  }

  if (loading && !userProfile) {
    return (
      <div className="min-h-screen bg-[#0d1f2d] p-4 md:p-8">
        <div className="mx-auto max-w-6xl">
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-white" />
          </div>
        </div>
      </div>
    )
  }

  if (userNotFound) {
    return (
      <div className="min-h-screen bg-[#0d1f2d] flex flex-col">
        <div className="flex-1 flex items-center justify-center p-4 md:p-8">
          <div className="w-full max-w-md">
            <div className="relative overflow-hidden rounded-3xl">
              <div className="absolute inset-0 bg-gradient-to-br from-red-400 via-orange-400 to-yellow-400"></div>
              <div className="absolute inset-0 bg-white/10 backdrop-blur-xl"></div>
              <div
                className="absolute inset-0"
                style={{
                  background: "linear-gradient(120deg, rgba(255,255,255,0.45) 0%, rgba(255,255,255,0) 60%)",
                  mixBlendMode: "screen",
                }}
              ></div>
              <div className="relative z-10 p-8 md:p-12 text-center">
                <div className="mb-6">
                  <svg className="mx-auto h-20 w-20 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
                <h2 className="mb-3 text-3xl md:text-4xl font-bold text-white drop-shadow-lg">User Not Found</h2>
                <p className="mb-8 text-lg text-white/90 drop-shadow">
                  We couldn't find a Farcaster account with "{searchInput}". Please check the username or FID and try
                  again.
                </p>
                <Button
                  onClick={() => {
                    setUserNotFound(false)
                    setSearchInput("")
                    setFid(239530)
                  }}
                  className="bg-white/20 hover:bg-white/30 text-white border-2 border-white/40 backdrop-blur-sm text-lg px-8 py-6 rounded-xl font-semibold shadow-lg transition-all"
                >
                  Search Again
                </Button>
              </div>
            </div>
          </div>
        </div>
        <nav className="fixed bottom-0 left-0 right-0 bg-white/10 backdrop-blur-md border-t border-white/20 z-50 md:hidden">
          <div className="flex items-center justify-around py-4 px-4">
            <button
              onClick={() => {
                setUserNotFound(false)
                setSearchInput("")
                setFid(239530)
                fetchData()
              }}
              className="flex flex-col items-center gap-1 text-white hover:text-white/80 transition-colors"
            >
              <Home className="h-6 w-6" />
              <span className="text-xs font-medium">Home</span>
            </button>
            <button
              onClick={() => {
                fetchData()
              }}
              className="flex flex-col items-center gap-1 text-white/60 hover:text-white/80 transition-colors"
            >
              <User className="h-6 w-6" />
              <span className="text-xs font-medium">Profile</span>
            </button>
          </div>
        </nav>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background p-4 md:p-8">
        <div className="mx-auto max-w-6xl">
          <Card>
            <CardHeader>
              <CardTitle className="text-destructive">Error</CardTitle>
              <CardDescription>{error}</CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={fetchData} variant="outline">
                <RefreshCw className="mr-2 h-4 w-4" />
                Try Again
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  if (showProfileGenerator) {
    return (
      <div className="min-h-screen bg-[#0d1f2d] text-white p-4 md:p-8 pb-24 md:pb-8">
        <div className="max-w-6xl mx-auto">
          <div className="mb-6">
            <button
              onClick={() => setShowProfileGenerator(false)}
              className="flex items-center gap-2 text-white/80 hover:text-white transition-colors mb-4"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
              Back
            </button>
            <h1 className="text-2xl md:text-3xl font-bold text-white">Profile Card Generator</h1>
            <p className="text-sm md:text-base text-white/80 mt-2">
              Customize your profile card and share it on Farcaster
            </p>
          </div>
          <div className="mb-6">
            <div
              className={`relative rounded-3xl overflow-hidden h-auto min-h-[16rem] ${cardBackgrounds[cardBackground]}`}
            >
              <div className="absolute inset-0 bg-white/20 backdrop-blur-xl"></div>
              <div
                className="absolute inset-0"
                style={{
                  background:
                    "linear-gradient(120deg, rgba(255,255,255,0.3) 0%, rgba(255,255,255,0.25) 40%, rgba(255,255,255,0.08) 40%), linear-gradient(0deg, rgba(255,255,255,0.20), rgba(255,255,255,0.30))",
                  backgroundSize: "150% 150%",
                  mixBlendMode: "screen",
                }}
              ></div>
              <div className="absolute top-4 right-4 md:top-6 md:right-6 z-10">
                <div
                  className={`rounded-xl backdrop-blur-md px-3 py-2 sm:px-4 shadow-lg ${getNeynarScoreColor(stats.neynar_score).bg} ${getNeynarScoreColor(stats.neynar_score).border} border`}
                >
                  <div
                    className={`text-xs text-center font-medium ${getNeynarScoreColor(stats.neynar_score).textLabel}`}
                  >
                    Neynar Score
                  </div>
                  <div
                    className={`text-xl sm:text-2xl font-bold text-center ${getNeynarScoreColor(stats.neynar_score).textScore}`}
                  >
                    {stats.neynar_score.toFixed(2)}
                  </div>
                </div>
              </div>
              <div className="relative z-10 p-6">
                <div className="flex flex-col gap-6 pr-24 md:pr-32">
                  <div className="flex flex-col sm:flex-row items-start space-y-4 sm:space-y-0 sm:space-x-4">
                    <Avatar className="h-20 w-20 border-4 border-white shadow-xl">
                      <AvatarImage src={userProfile?.pfp_url || "/placeholder.svg"} alt={userProfile?.display_name} />
                      <AvatarFallback className="bg-white/40 text-purple-900 backdrop-blur-sm font-semibold text-2xl">
                        {userProfile?.display_name?.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="space-y-2">
                      <h2 className="text-2xl sm:text-3xl font-bold text-white drop-shadow-md">
                        {userProfile?.display_name}
                      </h2>
                      <p className="text-base sm:text-lg text-white/90 drop-shadow">@{userProfile?.username}</p>
                      <div className="flex flex-wrap gap-4 pt-2 text-sm sm:text-base">
                        <div className="text-white drop-shadow">
                          <span className="font-semibold">{userProfile?.follower_count?.toLocaleString()}</span>
                          <span className="text-white/90"> followers</span>
                        </div>
                        <div className="text-white drop-shadow">
                          <span className="font-semibold">{userProfile?.following_count?.toLocaleString()}</span>
                          <span className="text-white/90"> following</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-white mb-3">Choose Background</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {Object.entries(cardBackgrounds).map(([key, bgClass]) => (
                <button
                  key={key}
                  onClick={() => setCardBackground(key)}
                  className={`h-20 rounded-xl ${bgClass} border-4 transition-all ${
                    cardBackground === key ? "border-white scale-105" : "border-transparent hover:border-white/50"
                  }`}
                />
              ))}
            </div>
          </div>
          <button
            onClick={generateProfileCard}
            className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-4 rounded-xl font-semibold text-lg shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2"
          >
            <Share2 className="h-5 w-5" />
            Share to Farcaster
          </button>
        </div>
        <nav className="fixed bottom-0 left-0 right-0 bg-white/10 backdrop-blur-md border-t border-white/20 z-50 md:hidden">
          <div className="flex items-center justify-around py-4 px-4">
            <button
              onClick={() => {
                setShowProfileGenerator(false)
                setUserNotFound(false)
                setSearchInput("")
                setFid(239530)
                fetchData()
              }}
              className="flex flex-col items-center gap-1 text-white/60 hover:text-white/80 transition-colors"
            >
              <Home className="h-6 w-6" />
              <span className="text-xs font-medium">Home</span>
            </button>
            <button
              onClick={() => setShowProfileGenerator(true)}
              className="flex flex-col items-center gap-1 text-white hover:text-white/80 transition-colors"
            >
              <User className="h-6 w-6" />
              <span className="text-xs font-medium">Profile</span>
            </button>
          </div>
        </nav>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8 pb-24 md:pb-8">
      <div className="mx-auto max-w-6xl space-y-6">
        <div className="w-full rounded-2xl md:rounded-3xl p-5 sm:p-6 md:p-8 bg-gradient-to-br from-[#b5dfee]/70 to-[#d7ebfa]/70 backdrop-blur-xl shadow-xl border border-white/20">
          <h1 className="text-xl sm:text-2xl md:text-3xl font-bold mb-2 text-black">Search Farcaster Account</h1>
          <p className="text-black/70 mb-5 sm:mb-6 text-sm sm:text-base">
            Enter a Farcaster ID (FID) or username to view account activity
          </p>
          <div className="mb-4 sm:mb-5">
            <input
              type="text"
              placeholder="Enter FID or username"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              className="w-full px-4 py-3 sm:py-3.5 rounded-xl bg-white/50 placeholder-black/50 border border-black/10 focus:outline-none focus:ring-2 focus:ring-blue-500/40 text-black backdrop-blur-sm text-base"
            />
          </div>
          <button
            onClick={handleSearch}
            disabled={isSearching || !searchInput.trim()}
            className="w-full py-3 sm:py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium shadow-md flex items-center justify-center gap-2 transition text-base"
          >
            <Search className="w-5 h-5" />
            {isSearching ? "Searching..." : "Search"}
          </button>
        </div>
        <div className="relative rounded-3xl overflow-hidden h-auto min-h-[12rem]">
          <div className="absolute inset-0 bg-gradient-to-br from-pink-300 via-purple-400 to-blue-400"></div>
          <div className="absolute inset-0 bg-white/20 backdrop-blur-xl"></div>
          <div
            className="absolute inset-0"
            style={{
              background: "linear-gradient(120deg, rgba(255,255,255,0.3) 0%, rgba(255,255,255,0) 60%)",
              mixBlendMode: "screen",
            }}
          ></div>
          <div className="absolute top-4 right-4 md:top-6 md:right-6 z-10">
            <div
              className={`rounded-xl backdrop-blur-md px-3 py-2 sm:px-4 shadow-lg ${getNeynarScoreColor(stats.neynar_score).bg} ${getNeynarScoreColor(stats.neynar_score).border} border`}
            >
              <div className={`text-xs text-center font-medium ${getNeynarScoreColor(stats.neynar_score).textLabel}`}>
                Neynar Score
              </div>
              <div
                className={`text-xl sm:text-2xl font-bold text-center ${getNeynarScoreColor(stats.neynar_score).textScore}`}
              >
                {stats.neynar_score.toFixed(2)}
              </div>
            </div>
          </div>
          <div className="relative z-10 p-6">
            <div className="flex flex-col gap-6 md:flex-row md:items-start md:justify-between pr-24 md:pr-32">
              <div className="flex flex-col sm:flex-row items-start space-y-4 sm:space-y-0 sm:space-x-4">
                <Avatar className="h-16 w-16 border-4 border-white shadow-xl">
                  <AvatarImage src={userProfile?.pfp_url || "/placeholder.svg"} alt={userProfile?.display_name} />
                  <AvatarFallback className="bg-white/40 text-purple-900 backdrop-blur-sm font-semibold">
                    {userProfile?.display_name?.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div className="space-y-1">
                  <h2 className="text-xl sm:text-2xl font-bold text-white drop-shadow-md">
                    {userProfile?.display_name}
                  </h2>
                  <p className="text-sm sm:text-base text-white/90 drop-shadow">@{userProfile?.username}</p>
                  {userProfile?.profile?.bio?.text && (
                    <p className="mt-2 text-sm text-white/85 drop-shadow line-clamp-2">
                      {userProfile.profile.bio.text}
                    </p>
                  )}
                  <div className="flex flex-wrap gap-3 sm:gap-4 pt-2 text-xs sm:text-sm">
                    <div className="text-white drop-shadow">
                      <span className="font-semibold">{userProfile?.follower_count?.toLocaleString()}</span>
                      <span className="text-white/90"> followers</span>
                    </div>
                    <div className="text-white drop-shadow">
                      <span className="font-semibold">{userProfile?.following_count?.toLocaleString()}</span>
                      <span className="text-white/90"> following</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="grid gap-4 sm:gap-6 grid-cols-1 sm:grid-cols-3">
          <div className="relative rounded-3xl overflow-hidden h-48 shadow-[0_0px_8px_rgba(0,0,0,0.12),0_2px_16px_rgba(0,0,0,0.12),0_4px_20px_rgba(0,0,0,0.12),0_12px_28px_rgba(0,0,0,0.12)]">
            <div className="absolute inset-0 bg-gradient-to-br from-pink-200 via-rose-300 to-pink-400"></div>
            <div className="absolute inset-0 bg-white/10 backdrop-blur-xl"></div>
            <div
              className="absolute inset-0 animate-[cardGradient_45s_ease-in-out_infinite]"
              style={{
                background:
                  "linear-gradient(120deg, rgba(255,255,255,0.02) 30%, rgba(255,255,255,0.25) 40%, rgba(255,255,255,0.08) 40%), linear-gradient(0deg, rgba(255,255,255,0.20), rgba(255,255,255,0.30))",
                backgroundSize: "150% 150%",
                mixBlendMode: "screen",
              }}
            ></div>
            <div className="absolute inset-0 shadow-[inset_0_-1px_0_0_rgba(255,255,255,0.9),inset_0_1px_0_0_rgba(0,0,0,0.2)] rounded-3xl pointer-events-none"></div>
            <div className="relative z-10 p-6 h-full flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase tracking-wider font-medium" style={{ color: "#0d1f2d" }}>
                  Estimated Likes
                </span>
                <Heart className="h-5 w-5 text-rose-600" />
              </div>
              <div>
                <div className="text-3xl font-bold mb-1" style={{ color: "#142430" }}>
                  {stats.total_likes.toLocaleString()}
                </div>
                <p className="text-xs" style={{ color: "rgba(20, 36, 48, 0.8)" }}>
                  Last {timePeriod === "24h" ? "24 hours" : timePeriod === "week" ? "7 days" : "1 month"}
                </p>
              </div>
            </div>
          </div>
          <div className="relative rounded-3xl overflow-hidden h-48 shadow-[0_0px_8px_rgba(0,0,0,0.12),0_2px_16px_rgba(0,0,0,0.12),0_4px_20px_rgba(0,0,0,0.12),0_12px_28px_rgba(0,0,0,0.12)]">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-200 via-indigo-300 to-blue-400"></div>
            <div className="absolute inset-0 bg-white/10 backdrop-blur-xl"></div>
            <div
              className="absolute inset-0 animate-[cardGradient_45s_ease-in-out_infinite]"
              style={{
                background:
                  "linear-gradient(120deg, rgba(255,255,255,0.02) 30%, rgba(255,255,255,0.25) 40%, rgba(255,255,255,0.08) 40%), linear-gradient(0deg, rgba(255,255,255,0.20), rgba(255,255,255,0.30))",
                backgroundSize: "150% 150%",
                mixBlendMode: "screen",
              }}
            ></div>
            <div className="absolute inset-0 shadow-[inset_0_-1px_0_0_rgba(255,255,255,0.9),inset_0_1px_0_0_rgba(0,0,0,0.2)] rounded-3xl pointer-events-none"></div>
            <div className="relative z-10 p-6 h-full flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase tracking-wider font-medium" style={{ color: "#0d1f2d" }}>
                  Estimated Casts
                </span>
                <MessageSquare className="h-5 w-5 text-indigo-600" />
              </div>
              <div>
                <div className="text-3xl font-bold mb-1" style={{ color: "#142430" }}>
                  {stats.total_casts.toLocaleString()}
                </div>
                <p className="text-xs" style={{ color: "rgba(20, 36, 48, 0.8)" }}>
                  Last {timePeriod === "24h" ? "24 hours" : timePeriod === "week" ? "7 days" : "1 month"}
                </p>
              </div>
            </div>
          </div>
          <div className="relative rounded-3xl overflow-hidden h-48 shadow-[0_0px_8px_rgba(0,0,0,0.12),0_2px_16px_rgba(0,0,0,0.12),0_4px_20px_rgba(0,0,0,0.12),0_12px_28px_rgba(0,0,0,0.12)]">
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-200 via-teal-300 to-green-400"></div>
            <div className="absolute inset-0 bg-white/10 backdrop-blur-xl"></div>
            <div
              className="absolute inset-0 animate-[cardGradient_45s_ease-in-out_infinite]"
              style={{
                background:
                  "linear-gradient(120deg, rgba(255,255,255,0.02) 30%, rgba(255,255,255,0.25) 40%, rgba(255,255,255,0.08) 40%), linear-gradient(0deg, rgba(255,255,255,0.20), rgba(255,255,255,0.30))",
                backgroundSize: "150% 150%",
                mixBlendMode: "screen",
              }}
            ></div>
            <div className="absolute inset-0 shadow-[inset_0_-1px_0_0_rgba(255,255,255,0.9),inset_0_1px_0_0_rgba(0,0,0,0.2)] rounded-3xl pointer-events-none"></div>
            <div className="relative z-10 p-6 h-full flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase tracking-wider font-medium" style={{ color: "#0d1f2d" }}>
                  Estimated Recasts
                </span>
                <Repeat2 className="h-5 w-5 text-teal-600" />
              </div>
              <div>
                <div className="text-3xl font-bold mb-1" style={{ color: "#142430" }}>
                  {stats.total_recasts.toLocaleString()}
                </div>
                <p className="text-xs" style={{ color: "rgba(20, 36, 48, 0.8)" }}>
                  Last {timePeriod === "24h" ? "24 hours" : timePeriod === "week" ? "7 days" : "1 month"}
                </p>
              </div>
            </div>
          </div>
        </div>
        <Card className="border-border shadow-sm">
          <CardHeader>
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div>
                <CardTitle className="flex items-center gap-2 text-lg sm:text-xl text-gray-900">
                  <TrendingUp className="h-4 w-4 sm:h-5 sm:w-5" />
                  Activity Overview
                </CardTitle>
                <CardDescription className="text-xs sm:text-sm text-gray-700">
                  Estimated activity pattern based on your profile stats
                </CardDescription>
              </div>
              <div className="flex flex-col sm:flex-row gap-2">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full sm:w-auto bg-card hover:bg-muted border-border"
                    >
                      {getTimePeriodLabel()}
                      <ChevronDown className="ml-2 h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => setTimePeriod("24h")}>Last 24 Hours Activity</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setTimePeriod("week")}>Weekly Activity</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setTimePeriod("month")}>Last 1 Month Activity</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleRefresh}
                  className="w-full sm:w-auto bg-card hover:bg-muted border-border"
                >
                  <RefreshCw className={`mr-2 h-4 w-4 ${refreshing ? "animate-spin" : ""}`} />
                  Refresh
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={exportToCSV}
                  className="w-full sm:w-auto bg-card hover:bg-muted border-border"
                >
                  <Download className="mr-2 h-4 w-4" />
                  Export CSV
                </Button>
                <Button
                  variant="default"
                  size="sm"
                  onClick={shareToFarcaster}
                  className="w-full sm:w-auto bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  <Share2 className="mr-2 h-4 w-4" />
                  Share
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="relative" style={{ height: window.innerWidth < 640 ? 300 : 400 }}>
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={activityData}
                  margin={{
                    top: 10,
                    right: window.innerWidth < 640 ? 0 : 20,
                    left: window.innerWidth < 640 ? -8 : 8,
                    bottom: 8,
                  }}
                >
                  <CartesianGrid stroke="var(--border)" strokeDasharray="4 4" vertical={false} />
                  <XAxis
                    dataKey="date"
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: "hsl(var(--muted-foreground))", fontSize: window.innerWidth < 640 ? 10 : 12 }}
                    padding={{ left: 6, right: 6 }}
                  />
                  <YAxis
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: "hsl(var(--muted-foreground))", fontSize: window.innerWidth < 640 ? 10 : 11 }}
                    width={window.innerWidth < 640 ? 32 : 42}
                  />
                  <Tooltip content={<CustomTooltip />} wrapperStyle={{ outline: "none" }} />
                  <defs>
                    <linearGradient id="likesGrad" x1="0" x2="0" y1="0" y2="1">
                      <stop offset="0%" stopColor="#FF6B98" stopOpacity={0.36} />
                      <stop offset="60%" stopColor="#FF6B98" stopOpacity={0.14} />
                      <stop offset="100%" stopColor="#FF6B98" stopOpacity={0.02} />
                    </linearGradient>
                    <linearGradient id="castsGrad" x1="0" x2="0" y1="0" y2="1">
                      <stop offset="0%" stopColor="#4C59FF" stopOpacity={0.36} />
                      <stop offset="60%" stopColor="#4C59FF" stopOpacity={0.14} />
                      <stop offset="100%" stopColor="#4C59FF" stopOpacity={0.02} />
                    </linearGradient>
                    <linearGradient id="recastsGrad" x1="0" x2="0" y1="0" y2="1">
                      <stop offset="0%" stopColor="#4CCB8F" stopOpacity={0.36} />
                      <stop offset="60%" stopColor="#4CCB8F" stopOpacity={0.14} />
                      <stop offset="100%" stopColor="#4CCB8F" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <Area
                    type="monotone"
                    dataKey="likes"
                    stroke="#FF6B98"
                    strokeWidth={2.5}
                    fill="url(#likesGrad)"
                    dot={<CustomDot dataKey="likes" />}
                    activeDot={{ r: 5, strokeWidth: 2, stroke: "#ffffff" }}
                  />
                  <Area
                    type="monotone"
                    dataKey="casts"
                    stroke="#4C59FF"
                    strokeWidth={2.5}
                    fill="url(#castsGrad)"
                    dot={<CustomDot dataKey="casts" />}
                    activeDot={{ r: 5, strokeWidth: 2, stroke: "#ffffff" }}
                  />
                  <Area
                    type="monotone"
                    dataKey="recasts"
                    stroke="#4CCB8F"
                    strokeWidth={2.5}
                    fill="url(#recastsGrad)"
                    dot={<CustomDot dataKey="recasts" />}
                    activeDot={{ r: 5, strokeWidth: 2, stroke: "#ffffff" }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-6 grid grid-cols-3 gap-4 border-t border-border pt-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">
                  {(stats.total_likes / (timePeriod === "24h" ? 1 : timePeriod === "week" ? 7 : 30)).toFixed(1)}
                </div>
                <div className="text-xs text-gray-700 mt-1">Likes/day</div>
                <div className="mt-2 h-1 rounded-full bg-muted">
                  <div className="h-1 rounded-full" style={{ width: "75%", backgroundColor: "#FF6B98" }} />
                </div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">
                  {(stats.total_casts / (timePeriod === "24h" ? 1 : timePeriod === "week" ? 7 : 30)).toFixed(1)}
                </div>
                <div className="text-xs text-gray-700 mt-1">Casts/day</div>
                <div className="mt-2 h-1 rounded-full bg-muted">
                  <div className="h-1 rounded-full" style={{ width: "60%", backgroundColor: "#4C59FF" }} />
                </div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">
                  {(stats.total_recasts / (timePeriod === "24h" ? 1 : timePeriod === "week" ? 7 : 30)).toFixed(1)}
                </div>
                <div className="text-xs text-gray-700 mt-1">Recasts/day</div>
                <div className="mt-2 h-1 rounded-full bg-muted">
                  <div className="h-1 rounded-full" style={{ width: "85%", backgroundColor: "#4CCB8F" }} />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      <nav className="fixed bottom-0 left-0 right-0 bg-white/10 backdrop-blur-md border-t border-white/20 z-50 md:hidden">
        <div className="flex items-center justify-around py-4 px-4">
          <button
            onClick={() => {
              setUserNotFound(false)
              setSearchInput("")
              setFid(239530)
              fetchData()
            }}
            className="flex flex-col items-center gap-1 text-white hover:text-white/80 transition-colors"
          >
            <Home className="h-6 w-6" />
            <span className="text-xs font-medium">Home</span>
          </button>
          <button
            onClick={() => setShowProfileGenerator(true)}
            className="flex flex-col items-center gap-1 text-white hover:text-white/80 transition-colors"
          >
            <User className="h-6 w-6" />
            <span className="text-xs font-medium">Profile</span>
          </button>
        </div>
      </nav>
    </div>
  )
}
